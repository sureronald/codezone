#include <iostream>

using namespace std;

int main()
{
  cout <<"code zone beta 2010"<<endl;
  return 0;
}
